from flask import Flask, render_template, request
import json
from flask_datepicker import datepicker
import datetime
import ast
import requests

app = Flask(__name__)

# Cheia de autentificare pentru API-ul Hotels
API_KEY = '607305c08cmsh8dd1b5580259e66p1bfe9ejsn232c2b39f6e7'

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/hotels', methods=['GET', 'POST'])
def hotels():
    url = "https://hotels4.p.rapidapi.com/properties/v2/list"

    check_in = request.args.get('check-in')
    check_out = request.args.get('check-out')
    #num_rooms = request.args.get('num-rooms')
    num_travellers = request.args.get('num-travellers')
    # print(num_rooms, num_travellers)
    destination = request.args.get('destination')

    #print(destination)

    destination_dict = {
        'latitude': float(destination.split(' ')[0]),
        'longitude': float(destination.split(' ')[1])
    }
    #print(destination_dict)
    check_in_dict = {
        'day': int(check_in.split('-')[2]),
        'month': int(check_in.split('-')[1]),
        'year': int(check_in.split('-')[0])
    }

    check_out_dict = {
        'day': int(check_out.split('-')[2]),
        'month': int(check_out.split('-')[1]),
        'year': int(check_out.split('-')[0])
    }

    # Check if a sorting filter is specified in the request
    filter_value = request.args.get('sort')
    if filter_value==None:
        filter_value="RECOMMENDED"

    """
    # Modify the payload based on the filter value
    if filter_value == 'recommended':
        sort_option = "RECOMMENDED"
    elif filter_value == 'price-low-to-high':
        sort_option = "PRICE_LOW_TO_HIGH"
    elif filter_value == 'price-high-to-low':
        sort_option = "PRICE_HIGH_TO_LOW"
    elif filter_value == 'distance':
        sort_option = "DISTANCE"
    elif filter_value == 'rating':
        sort_option = "REVIEW_RELEVANT"
    elif filter_value == 'property-class':
        sort_option = "PROPERTY_CLASS"
    else:
        sort_option = "RECOMMENDED"  # Set a default sort option
    """
    headers = {
        "content-type": "application/json",
        "X-RapidAPI-Key": "5fbc045366msh8a95618fc9afb3ap19795ejsn138b5df7840b",
        "X-RapidAPI-Host": "hotels4.p.rapidapi.com"
    }
    payload = {
        "currency": "USD",
        "eapid": 1,
        "locale": "en_US",
        "siteId": 300000001,
        "destination": {"coordinates": destination_dict},
        "checkInDate": check_in_dict,
        "checkOutDate": check_out_dict,
        "rooms": [
            {
                "adults": int(num_travellers),
                "children": []
            }
        ],
        "resultsStartingIndex": 0,
        "resultsSize": 200,
        "sort": filter_value,
        "filters": {"price": {
            "max": 700,
            "min": 10
        }}
    }
    print(payload)
    response = requests.request("POST", url, json=payload, headers=headers).json()

    return render_template('hotels.html', properties=response)

@app.route('/hotel_link', methods=['GET', 'POST'])
def hotel_link():
    url = "https://hotels4.p.rapidapi.com/properties/v2/detail"

    hotel_id = request.args.get('id')

    payload = {
        "currency": "USD",
        "eapid": 1,
        "locale": "en_US",
        "siteId": 300000001,
        "propertyId": hotel_id
    }
    print(payload)
    headers = {
        "content-type": "application/json",
        "X-RapidAPI-Key": "5fbc045366msh8a95618fc9afb3ap19795ejsn138b5df7840b",
        "X-RapidAPI-Host": "hotels4.p.rapidapi.com"
    }

    response = requests.request("POST", url, json=payload, headers=headers).json()
    #data = json.loads(response)

    return render_template('hotel_link.html', hotel_link=response['data']['propertyInfo'])

if __name__ == '__main__':
    app.run(debug=True)
