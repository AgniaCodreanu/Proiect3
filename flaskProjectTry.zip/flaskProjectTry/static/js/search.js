$(document).ready(function() {
  $('.selectpicker').selectpicker();

  $('.bs-searchbox > input').on('input', function() {
    var query = $(this).val();
    var url = 'https://example.com/api/endpoint?q=' + query;

    $.ajax({
      url: 'https://hotels4.p.rapidapi.com/locations/v3/search',
                method: 'GET',
                headers: {
                    'x-rapidapi-host': 'hotels4.p.rapidapi.com',
                    'x-rapidapi-key': '703ad93641msh095a4d680095257p14fa96jsn3577c7c039bb'
                },
                data: {
                    q: query,
                    locale: 'new york',
                    langid :'1033',
                    siteid: '300000001'
                },
      success: function(data) {
        // Populate the dropdown with the new options
        var options = [];
        $.each(data.sr, function(index, item) {
          options.push('<option value="' + item.coordinates + '">' + item.regionNames.displayName + '</option>');
        });
        $('.selectpicker').html(options.join(''));
        $('.selectpicker').selectpicker('refresh');
      },
      error: function(jqXHR, textStatus, errorThrown) {
        console.error(errorThrown);
      }
    });
  });
});
